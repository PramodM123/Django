
global MYSQL_USER
global MYSQL_PASSWORD
global MYSQL_HOST
global MYSQL_DB

MYSQL_USER ="root"
MYSQL_PASSWORD="admin123."
MYSQL_HOST="localhost"
MYSQL_DB="pmc_db"